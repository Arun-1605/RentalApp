from flask import Flask, render_template, jsonify
import pymysql

app = Flask(__name__)

# MySQL Database Connection
def get_db_connection():
    return pymysql.connect(
        host="your-db-host",
        user="your-db-username",
        password="your-db-password",
        database="bike_rental_db"
    )

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_bikes')
def get_bikes():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT * FROM bikes')
    bikes = cursor.fetchall()
    conn.close()
    return jsonify(bikes)

if __name__ == '__main__':
    app.run(debug=True)
